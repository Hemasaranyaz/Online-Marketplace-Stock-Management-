package onlinemarketplace;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class UserManagement {

    // DBHelper class for database connection
    static class DBHelper {
        private static final String URL = "jdbc:mysql://localhost:3306/online_stock"; // Database URL
        private static final String USER = "root"; // Your MySQL username
        private static final String PASSWORD = "Hema@22CS029"; // Your MySQL password

        // Method to get the database connection
        public static Connection getConnection() throws SQLException {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                return DriverManager.getConnection(URL, USER, PASSWORD);
            } catch (ClassNotFoundException | SQLException e) {
                throw new SQLException("Database connection failed", e);
            }
        }
    }

    // User model class for user-related data
    static class User {
        private int id;
        private String username;
        private String password;
        private String email;
        

        public User(String username, String password, String email) {
            this.username = username;
            this.password = password;
            this.email = email;
            
        }

        // Getters and Setters
        public int getId() { return id; }
        public void setId(int id) { this.id = id; }
        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        
    }

    // Product model class for product-related data
    static class Product {
        private int id;
        private int userId;  // Seller's ID
        private String name;
        private String description;
        private double price;
        private int stock;

        public Product(int userId, String name, String description, double price, int stock) {
            this.userId = userId;
            this.name = name;
            this.description = description;
            this.price = price;
            this.stock = stock;
        }

        // Getters and Setters
        public int getId() { return id; }
        public void setId(int id) { this.id = id; }
        public int getUserId() { return userId; }
        public void setUserId(int userId) { this.userId = userId; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
        public double getPrice() { return price; }
        public void setPrice(double price) { this.price = price; }
        public int getStock() { return stock; }
        public void setStock(int stock) { this.stock = stock; }

        @Override
        public String toString() {
            return "Product Name: " + name +
                    "\nPrice: $" + price +
                    "\nDescription: " + description +
                    "\nStock: " + stock +
                    "\n=====================================";
        }
    }

    // Data Access Object for User operations
    static class UserDAO {
        // Register a new user
        public static boolean registerUser(String username, String password, String email, String role) throws SQLException {
            String checkUserSql = "SELECT * FROM users WHERE username = ?";
            try (Connection conn = DBHelper.getConnection();
                 PreparedStatement checkStmt = conn.prepareStatement(checkUserSql)) {
                checkStmt.setString(1, username);
                try (ResultSet rs = checkStmt.executeQuery()) {
                    if (rs.next()) {
                        // If the user already exists, return false
                        System.out.println("Username already taken.");
                        return false;
                    }
                }
            }

            // If the username is available, proceed with the registration
            String insertUserSql = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
            try (Connection conn = DBHelper.getConnection();
                 PreparedStatement insertStmt = conn.prepareStatement(insertUserSql)) {

                insertStmt.setString(1, username);
                insertStmt.setString(2, password);
                insertStmt.setString(3, email);
             

                int rowsAffected = insertStmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("User registered successfully!");
                    return true;
                } else {
                    System.out.println("User registration failed.");
                    return false;
                }
            }
        }

        // Authenticate user during login
        public static boolean authenticateUser(String username, String password) throws SQLException {
            String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
            try (Connection conn = DBHelper.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setString(1, username);
                stmt.setString(2, password);
                try (ResultSet rs = stmt.executeQuery()) {
                    return rs.next(); // If result found, user is authenticated
                }
            }
        }
    }

    // Data Access Object for Product operations
    static class ProductDAO {
        public static List<Product> searchProducts(String searchQuery) throws SQLException {
            String sql = "SELECT * FROM products WHERE name LIKE ? OR description LIKE ?";
            try (Connection conn = DBHelper.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {

                String searchTerm = "%" + searchQuery + "%";
                stmt.setString(1, searchTerm);
                stmt.setString(2, searchTerm);

                try (ResultSet rs = stmt.executeQuery()) {
                    List<Product> products = new ArrayList<>();
                    while (rs.next()) {
                        Product product = new Product(
                                rs.getInt("user_id"),
                                rs.getString("name"),
                                rs.getString("description"),
                                rs.getDouble("price"),
                                rs.getInt("stock")
                        );
                        products.add(product);
                    }
                    return products;
                }
            }
        }
    }

    // Main application logic
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Register or authenticate users, then show marketplace
        System.out.println("Enter 1 for Registration, 2 for Login:");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline character

        if (choice == 1) {
            // Register user
            System.out.println("Enter username:");
            String username = scanner.nextLine();
            System.out.println("Enter password:");
            String password = scanner.nextLine();
            System.out.println("Enter email:");
            String email = scanner.nextLine();

            // Default role is 'buyer'
            String role = "buyer";

            try {
                boolean success = UserDAO.registerUser(username, password, email, role);
                if (!success) {
                    System.out.println("Registration failed. Try again with a different username.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else if (choice == 2) {
            // Login
            System.out.println("Enter username:");
            String username = scanner.nextLine();
            System.out.println("Enter password:");
            String password = scanner.nextLine();

            try {
                if (UserDAO.authenticateUser(username, password)) {
                    System.out.println("Login successful!");

                    // After login, allow user to search products
                    System.out.println("Enter product name or description to search:");
                    String searchQuery = scanner.nextLine();

                    // Call ProductDAO to search for products
                    List<Product> products = ProductDAO.searchProducts(searchQuery);
                    if (products.isEmpty()) {
                        System.out.println("No products found.");
                    } else {
                        for (Product product : products) {
                            System.out.println(product); // Display product details
                        }
                    }
                } else {
                    System.out.println("Invalid credentials.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        scanner.close();
    }
}
